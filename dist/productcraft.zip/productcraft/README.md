# ProductCraft

**A Sora Labs Agent Skill** · version 1.11.1 · MIT License · part of [All-in-One AI Skills](../../README.md)

ProductCraft is one installable skill that teaches a coding agent to build, harden and ship software that **shows the important thing first, behaves honestly, is proven by checks that actually ran, works on every device, and is secure and lawful where it matters**. It routes each task to only the modules that task needs: a bug fix reads the engineering workflow, a table change reads the table guidance, an auth change reads the auth-defense module, a destructive command triggers the agent-safety stop-check, and a launch reads the security and legal-readiness reviews.

Beyond application code, it covers the work around it: language and framework guides, cloud infrastructure, databases and data engineering, machine learning and statistics, scientific computing, life sciences, research writing, creative media, search visibility, third-party API integrations, blockchain development, AI agent engineering, networking and business operations. Each is a module with its own guide, focused references and tested helper scripts, read only when a task needs it.

It is a working skill for real codebases, not a theme pack, legal service or security certification. Its reference screens are code to learn from, not a component kit to paste. The agent changes your real codebase and reports what it actually tested.

## What's inside

| Module | Use it for | Entry file |
|---|---|---|
| **Engineering workflow** | Any non-trivial code change: Quick/Standard/Deep tracks, done-when checks, planning, test-first, root-cause debugging, small diffs, verification, review of your own and others' changes, finishing a branch | `modules/engineering-workflow/GUIDE.md` |
| **Engineering practices** | API contracts, data and safe migrations, resilience, performance, observability, CI/CD and releases, dependencies, docs, design docs and ADRs, large refactors, TypeScript, git and PRs, session handoff, whole-repository health audits, advanced testing (property-based, mutation, fuzzing, differential), spec compliance and unit checks, open-source release readiness, repository hygiene | `modules/engineering-practices/GUIDE.md` |
| **UI Distiller** | New screens, redesigns, cleaning up cluttered or "AI-looking" frontends, with taste detectors and a catalog of visual directions with contrast-checked palettes | `modules/ui-distiller/GUIDE.md` |
| **Product design** | Information hierarchy, tokens, spacing, density, Keep/Promote/Compress/Demote/Remove audits | `modules/product-design.md` |
| **Interaction & feedback** | Buttons, switches, sliders, drag and drop, modals, toasts, motion, optimistic vs. verified state | `modules/interaction-feedback.md` |
| **Forms & conversion** | Signup, OTP, passwords, search, uploads, checkout and payment UI | `modules/forms-conversion.md` |
| **Data & product surfaces** | Tables, dashboards, charts chosen from the question they answer, calendars, Kanban, chat, command palettes | `modules/data-and-product-surfaces.md` |
| **Responsive & accessibility** | Mobile layouts, touch targets, sheets vs. dialogs, keyboard, screen readers, i18n and RTL | `modules/responsive-accessibility.md` |
| **Ethical persuasion** | Funnels, copy and engagement without fake urgency, fake social proof or hidden fees | `modules/ethical-persuasion.md` |
| **Credential Shield** | Login, OTP/MFA, password reset, credential stuffing and password spraying defense | `modules/credential-shield/GUIDE.md` |
| **Code security review** | Multi-phase code audit: threat model, complete entry points with access classes, vulnerability classes mapped to OWASP and CWE, bugs typical of AI-written code, language pitfalls, static-analysis rules and SARIF triage, variant analysis, triage of outside reports, insecure defaults, supply-chain and CI agent-workflow review, proven findings, tested fixes and patch validation; domain guides for C and C++, Rust, cryptography, smart contracts, mobile apps and their backend rules, and YARA detection rules | `modules/code-security-review/GUIDE.md` |
| **LaunchGuard** | Pre-launch five-gate security review plus a 20-control security baseline: secrets, user data, authorization, payments, release go/no-go | `modules/launchguard/GUIDE.md` |
| **Legal ready** | 20 launch legal-readiness items: privacy, terms, refund and cookie policies, consent, data minimization, trackers, dark patterns, hidden fees, fake reviews, unsupported claims, accessibility, business details, children's data, unsubscribe, asset licenses, data deletion. General guidance, not legal advice | `modules/legal-ready/GUIDE.md` |
| **Agent safety** | Stop-check before destructive commands, secrets handled by name only, guided setup scripts the user runs for secrets, vetting third-party skills, plugins, MCP servers and hooks; optional command guard; isolating the agent in a devcontainer, container or VM | `modules/agent-safety/GUIDE.md` |
| **Codebase map** | Getting oriented in unfamiliar repositories: entry points, routes, import graph, symbols, hotspots, exclusions, import chains and dependency diagrams | `modules/codebase-map/GUIDE.md` |
| **Documents** | Word, Excel, PowerPoint and PDF: create, edit with formatting intact, extract, convert, fill forms, verified by rendering; animated GIFs and short clips with size, flash-rate and alt-text checks | `modules/documents/GUIDE.md` |
| **Builder tools** | Authoring and evaluating Agent Skills, designing and testing MCP servers, Playwright browser tests, linting agent configuration, finding, importing and updating skills safely | `modules/builder-tools/GUIDE.md` |
| **Stacks** | Language and framework guides that write code a maintainer of the stack would accept: Python, Django, FastAPI, Go, Rust, Java and Spring, Kotlin, C# and .NET, C++, PHP and Laravel, Ruby and Rails, Swift, React, Next.js, Vue and Nuxt, Angular, NestJS, React Native and Expo, Flutter, GraphQL, realtime, WordPress, Shopify, HTML email, game engines, firmware, Salesforce, CLI tools; system design and legacy modernization; a stack and version detector | `modules/stacks/GUIDE.md` |
| **Cloud infrastructure** | Terraform and OpenTofu (style, modules and state, tests, imports, Stacks, provider development), AWS CDK and serverless AWS, Azure modules, machine images, Kubernetes and Helm, containers and registries, GPU and serverless compute, static hosting, infrastructure pipelines, cost, architecture, SLOs, incidents, monitoring and chaos engineering; plan and diff only, with a Terraform plan reviewer | `modules/cloud-infrastructure/GUIDE.md` |
| **Data engineering** | SQL correctness and tuning, PostgreSQL, MySQL and SQL Server, safe read-only database access, pandas, Polars, DuckDB, Dask and Spark, Parquet and Zarr, exploratory analysis and data quality, charts and publication figures, geospatial and graph data, MATLAB interop, Kaggle, official statistics, filings and market-data APIs; an offline CSV profiler | `modules/data-engineering/GUIDE.md` |
| **ML engineering** | Models and LLM features with honest evaluation: leakage-safe splits, baselines and paired comparisons, scikit-learn, SHAP, UMAP, survival analysis, forecasting and time series, graph networks, PyTorch, Lightning and Transformers, fine-tuning, reinforcement learning, statistical tests and Bayesian models, MLOps, recommenders, RAG, prompts inside products and LLM evaluation | `modules/ml-engineering/GUIDE.md` |
| **Scientific computing** | Solvers, time integration and stability, discretization and meshes, verification and convergence studies, parameter studies with provenance, Slurm and profiling, SymPy, Astropy, quantum computing (Qiskit, Cirq, PennyLane, QuTiP), molecular dynamics, fluids, discrete-event simulation, materials and multi-objective optimization | `modules/scientific-computing/GUIDE.md` |
| **Life sciences** | Sequences, reads and variants, genomic intervals, single-cell and bulk expression, phylogenetics and microbiome, proteins and docking, cheminformatics, mass spectrometry, metabolic models; public biological, chemical and clinical databases with their licenses; DICOM and pathology images, de-identification, physiological signals, EHR models, clinical document drafts, medical-device quality systems, lab automation and lab data platforms. Research output, never medical advice | `modules/life-sciences/GUIDE.md` |
| **Research writing** | Literature search and systematic reviews, scholarly APIs, verified citations and BibTeX, source appraisal, hypotheses, scientific papers and reporting checklists, peer review, grants, stress tests for plans (devil's advocate, pre-mortem, red team, what-if), diagrams, posters, talks, paper pages, reports, newsletters, meeting notes, market and web research | `modules/research-writing/GUIDE.md` |
| **Creative media** | Generative art with seeded editions, posters and canvas designs, infographics, themes and brand application, reveal.js decks, programmatic video, prompting image and video models, image enhancement, EPUB books, file and invoice organization | `modules/creative-media/GUIDE.md` |
| **Integrations** | Third-party APIs: OAuth and scopes, token storage, webhooks with signature checks and deduplication, idempotency, rate limits, pagination, sync and contract tests; Stripe, Plaid, Supabase, Google Workspace, Jira, Confluence, Linear, Outline and membership platforms | `modules/integrations/GUIDE.md` |
| **Blockchain development** | Move on Aptos (language, objects and tokens, tests and the Move Prover, gas, CLI, TypeScript SDK, wallets, indexer) and Solana RPC; testnet first, no keys in chat, no investment advice | `modules/blockchain-dev/GUIDE.md` |
| **Search visibility** | Being found in search and AI answers: crawl and index controls (`robots.txt`, `noindex`, sitemaps, canonicals, status codes and redirects), JavaScript rendering, faceted navigation and pagination, site migrations, `hreflang`, on-page elements, site structure and internal links, structured data with dated feature status, Open Graph cards, Search Console, analytics and log measurement, rank tracking, links, authority and trust; keyword and topic research, results-page and competitor analysis, people-first writing and refreshes, E-E-A-T review, AI answer engines, entity clarity, programmatic pages; no spam tactics; an offline checker for built pages, `robots.txt` and sitemaps | `modules/search-visibility/GUIDE.md` |
| **Agent engineering** | Architecture audits and debugging of agent systems; harness construction; autonomous and scheduled loops with budgets, stop conditions, checkpoints and approval gates; agent evaluations, reviewer pairs and councils; context budgets and compaction; cost tracking, prompt caching and model routing; multi-agent orchestration; memory with consent; agents in shared channels; spending controls; a run-plan checker and a usage cost report | `modules/agent-engineering/GUIDE.md` |
| **Networking** | Cisco IOS and IOS-XE configuration and hardening, network automation, BGP diagnostics, configuration validation and drift, interface health, layer-by-layer troubleshooting; home and small-office design, VLANs, firewall basics, Pi-hole and WireGuard; an offline IOS configuration linter | `modules/networking/GUIDE.md` |
| **Business operations** | Supply chain (freight, customs and trade, energy, inventory, scheduling, quality and CAPA, returns), billing and reconciliation, investor materials, campaigns, brand voice, competitive analysis, publishing, email, product briefs, contract drafts and e-signature, translation of official documents; a safety-stock and reorder-point calculator. General information, not legal, tax, customs or investment advice | `modules/business-ops/GUIDE.md` |
| **UI rules** | A rulebook of screen-level rules with IDs (spacing, type, color, dark mode, buttons, forms, navigation, touch, feedback, components, icons, copy, screens, motion, front-end engineering, brand identity) | `modules/ui-rules.md` |
| **Language choice** | Offers Rust for new projects, services or performance-critical components, with honest trade-offs, and remembers the answer | `modules/language-choice.md` |
| **Lean output** | Opt-in shorter answers that never shorten safety warnings, security findings, errors or legal caveats | `modules/lean-output.md` |
| **Pattern library** | One principle, one implementation rule and one guardrail for each UI/UX pattern | `references/pattern-library.md` |
| **Reference screens** | 49 original HTML pages with 170 screens: 21 dashboards plus auth, settings, navigation, search, charts, cards, tables, forms, overlays, feedback, commerce, pricing, landing pages, mobile, messaging, onboarding and brand | `examples/README.md` |

The pattern library covers foundations, feedback, forms, interaction, navigation, responsive layout, data views, conversion, safety and advanced patterns such as live presence, chat and view transitions. A machine-readable version is in `references/pattern-index.json`.

## How it activates

`SKILL.md` is the single entry point. Its router picks modules from what the task actually touches:

| The task involves | ProductCraft reads |
|---|---|
| Any non-trivial code change in any language | Engineering workflow |
| A bug, a failing or flaky test, a regression | Engineering workflow's debugging loop |
| Property-based, mutation or fuzz testing; checking code against a spec; units and money arithmetic | The matching engineering-practices testing reference |
| Reviewing someone else's pull request | Engineering workflow's review reference, plus code security review for sensitive changes |
| APIs, schemas and migrations, performance, observability, CI/CD, dependencies, large refactors | The matching engineering-practices topic |
| A health check or audit of a whole repository | Engineering practices (repository health audit) |
| A new UI, a redesign, or decluttering | UI Distiller + product design + UI rules |
| Spacing, type, color, dark mode, buttons, form fields, navigation, icons, microcopy | The matching UI rules categories |
| Controls, motion, toasts, modals | Interaction & feedback |
| Forms, signup, OTP, checkout, search | Forms & conversion |
| Tables, dashboards, calendars, Kanban, chat, uploads | Data & product surfaces |
| Mobile layout, translation, RTL | Responsive & accessibility |
| Funnels, conversion copy, engagement | Ethical persuasion |
| A security review or audit of code, including AI-written code, C/C++ or Rust, cryptography, smart contracts, mobile apps and their backend rules, YARA detection rules | Code security review |
| Scanner results (SARIF), CI workflows that run AI agents, dependency and supply-chain risk, a reported vulnerability or a security patch | Code security review (static analysis, supply chain, triage, patch validation) |
| Login abuse, MFA, password reset | Credential Shield |
| API routes, data access, queries, uploads, cookies, headers, dependencies | The matching LaunchGuard security-baseline controls |
| Launch, payments, user data, privileged operations | LaunchGuard |
| Launch legal readiness: policies, consent, trackers, prices and claims, email, children's data, licenses, data deletion | Legal ready |
| Destructive commands, secrets on disk, installing third-party skills, plugins, MCP servers or hooks, sandboxing the agent | Agent safety |
| A setup that needs keys or secrets only the user should enter | Agent safety (guided setup script) |
| An unfamiliar or large repository | Codebase map |
| Making a repository public, choosing a license, cleaning up branches and issues | Engineering practices' open-sourcing or repository-hygiene reference |
| Word, Excel, PowerPoint or PDF files | Documents |
| An animated GIF, a chat emoji or a short demo clip | Documents (animated media) |
| Writing a skill, building an MCP server, Playwright tests, linting agent configuration, importing or updating skills | Builder tools |
| Requirements and acceptance criteria for a new feature, handing a task to a hosted coding agent, a Markdown task board | Engineering workflow's matching reference |
| Authorized dynamic web testing, captured HTTP traffic (HAR) | Code security review (dynamic testing, traffic captures) |
| Code in a specific language or framework, a toolchain, system design, legacy modernization, a framework upgrade | Stacks |
| Terraform, AWS CDK, Kubernetes, containers, cloud cost, SLOs, incidents, monitoring | Cloud infrastructure (plan and diff only) |
| SQL and databases, dataframes and large data, exploring a dataset, analysis charts, geospatial and graph data, public economic data | Data engineering |
| Training or evaluating models, statistics and A/B tests, ML pipelines, RAG and LLM features | ML engineering |
| Simulations, numerical methods, HPC jobs, scientific and quantum-computing libraries | Scientific computing |
| Genomics, single-cell, cheminformatics, biomedical databases, medical imaging, clinical documents, lab automation | Life sciences |
| Literature reviews, citations, scientific writing, peer review, grants, stress-testing a plan, posters and talks, reports and research | Research writing |
| Generative art, posters, infographics, themes, reveal.js, programmatic video, image prompts and enhancement, EPUB, organizing files | Creative media |
| Stripe, Plaid, Supabase, Google Workspace, Jira, Linear and other third-party APIs, OAuth and webhooks | Integrations |
| Move on Aptos, Solana RPC, dApps and wallets | Blockchain development |
| Pages missing from search, a search traffic drop, Search Console reports, `robots.txt`, sitemaps, canonicals, redirects, rendering | Search visibility (crawl, index and rendering references) |
| A site migration, replatform, domain or URL-structure change, or a multilingual site | Search visibility (migrations, `hreflang`) |
| Titles, meta descriptions, internal links, site structure, structured data, link previews | Search visibility (on-page, structure and structured-data references) |
| Search reports, rank tracking, alerts, backlinks, authority, AI crawler policy, AI referral traffic | Search visibility (measurement, links and trust references) |
| Keyword research, search intent, content gaps, writing or refreshing pages for search, E-E-A-T review, AI answer engines (GEO), entity clarity, programmatic pages | Search visibility (research, content and AI-answer references) |
| Building or operating AI agents, autonomous loops, agent evals, token and cost budgets, prompt caching, multi-agent orchestration, agent memory or spending | Agent engineering |
| Routers, switches, firewalls, Cisco IOS, BGP, VLANs, network outages, homelab networks, Pi-hole, WireGuard | Networking (show first; changes only with approval and a rollback) |
| Freight, customs, inventory, scheduling, quality, returns, billing, investor materials, campaigns, brand voice, contracts, official translations | Business operations (general information, not advice) |
| A new project, service or performance-critical component with no language fixed | Language choice (asks once about Rust) |
| A broad, ambiguous product task | Product design + interaction, then only what is relevant |

The security and legal modules are conditional. A copy or CSS tweak does not trigger a full audit, and a one-line fix stays on the Quick track.

## Install

### Claude Code (plugin marketplace)

```text
/plugin marketplace add Sora-Labs2026/All-in-One-AI-Skills
/plugin install productcraft@sora-labs-skills
```

### Copy into a project

```bash
git clone --depth 1 https://github.com/Sora-Labs2026/All-in-One-AI-Skills.git /tmp/sora-skills

# Claude Code
mkdir -p .claude/skills && cp -R /tmp/sora-skills/skills/productcraft .claude/skills/

# Codex and other agents that read .agents/skills
mkdir -p .agents/skills && cp -R /tmp/sora-skills/skills/productcraft .agents/skills/
```

Install it in one location only, so the skill doesn't trigger twice.

### ZIP upload to any coding-agent workspace

1. Download [`dist/productcraft.zip`](../../dist/productcraft.zip) and [`dist/PRODUCTCRAFT-WORKSPACE-SETUP-PROMPT.txt`](../../dist/PRODUCTCRAFT-WORKSPACE-SETUP-PROMPT.txt).
2. Upload the ZIP to your agent's workspace.
3. Paste the contents of the setup prompt. The agent inspects the archive, extracts it safely, installs it in the project-local skill directory, runs the package checks and adds the project rule below.

## Using it

Once installed, ProductCraft triggers on relevant work. You can also call it directly:

```text
Use productcraft to redesign the billing dashboard so the overdue invoices and the
"Send reminder" action are visible first on mobile and desktop.

Use productcraft to polish the settings screen: apply the UI rules for spacing, labels,
icons and navigation, and list the rule IDs you used.

Use productcraft on the signup and OTP flow: keep codes as strings, support paste and
autofill, and consult Credential Shield for the resend and verify endpoints.

Use productcraft to check this pull request against the security baseline and fix
any control it fails.

Use productcraft to prepare this app for launch. Run the LaunchGuard five gates and
write the report with PASS / FAIL / NOT_VERIFIED evidence.

Use productcraft to find out why the nightly export test fails only in CI, fix the
root cause and add a regression test.

Use productcraft to run a security review of the payments service and the code our
assistant generated last week; prove each finding before fixing it.

Use productcraft to get this store legally ready to launch in the EU and the US: cookie
consent, policies, unsubscribe links and a data deletion option.

Use productcraft to turn this CSV into a formatted Excel report with totals, then a
one-page PDF summary, and show me the rendered pages.

Use productcraft to build an MCP server for our ticketing API and test it.

Use productcraft to add property-based tests to the invoice parser and run a mutation
test on the billing module.

Use productcraft to review pull request 214 and tell me what it could break.

Use productcraft to get this repository ready to make public under Apache-2.0.

Use productcraft to triage the scanner results in results.sarif and check which
GitHub Actions workflows outsiders can trigger.

Use productcraft to upgrade this Django service to the next LTS and keep CI green.

Use productcraft to review this Terraform change and tell me what the plan would
destroy before anyone applies it.

Use productcraft to find out why this PostgreSQL query got slow and fix it with
before-and-after plans.

Use productcraft to compare these two models honestly and tell me whether the new
one is really better.

Use productcraft to run a differential expression analysis on these counts and
check the design for confounding first.

Use productcraft to draft the related-work section with citations you have verified.

Use productcraft to add Stripe checkout with verified webhooks and idempotent
fulfilment.

Use productcraft to find out why our product pages dropped out of Google after the
redesign, using Search Console evidence, and fix what is broken.

Use productcraft to add a budget, stop conditions and an approval gate to our
nightly agent loop, and show me what it costs per run.

Use productcraft to review this switch configuration for security problems before
we apply it in the maintenance window.
```

### Optional persistent project rule

Add this to your project's `CLAUDE.md` or `AGENTS.md` so the agent keeps using ProductCraft on future work:

> For significant frontend creation/redesign, UI interaction changes, complex forms, tables, dashboards, mobile layouts, or workflow UX, invoke the project-local ProductCraft skill and selectively read the matching design and interaction modules. Prioritize essential content, remove unnecessary visual noise, preserve accessible keyboard/touch behavior and real async/error handling. Use ethically transparent conversion techniques only; never fake scarcity, typing, fees, progress, social proof or server confirmations. For changes to auth/OTP/password recovery, consult its bundled Credential Shield module. For release preparation and changes to privileged operations, money, user data or production security, consult its bundled LaunchGuard module and check the matching security-baseline controls, or run the full five-gate review when shipping. Never apply the whole pattern library or run a full security audit on trivial copy/CSS edits. Keep reports honest and do not modify production secrets, cloud policy, live data or deployments without explicit authorization. For a new project, service or performance-critical component whose language is not yet fixed, ask once whether to write it in Rust, stating the trade-offs (faster runtime, slower compiles, more AI tokens, no automatic page-load gain) per its language-choice module. For any non-trivial code change, follow its engineering-workflow module (done-when checks, test-first where it fits, root-cause debugging, verification before claiming done). Before destructive commands or installing third-party skills, plugins, MCP servers or hooks, follow its agent-safety module. Before launch, also work through its legal-ready module as general guidance, not legal advice.

## Built-in guardrails

- **Verified over optimistic.** Payments, bookings, deletions, privileged changes and entitlements show *pending* until the server or provider confirms them.
- **Honest persuasion only.** Fake scarcity, phantom typing, artificial countdowns, hidden fees and hard-to-cancel flows are treated as anti-patterns to remove.
- **Accessibility first.** Semantic elements, keyboard and touch parity, reduced motion and visible focus outrank aesthetic formulas such as 60/30/10 or the golden ratio.
- **No false passes.** Scanners are advisory. Security checks report `PASS`, `FAIL`, `NEEDS_REVIEW`, `NOT_APPLICABLE` or `NOT_VERIFIED`, and secrets are never printed.
- **Hands off production.** No changes to real secrets, live data, payment provider settings or deployments without explicit permission.

## UI rules

`modules/ui-rules.md` routes to a rulebook in `references/ui-rules/`, one file per category. Every rule has an ID such as `BTN-02` with why it matters, what to do and what to avoid, so change reports can cite exactly which rules were applied. Rules are expressed through the project's existing tokens and components, accessibility and platform guidelines always win, and the optional style treatments are used only when asked for.

| Prefix | Covers |
|---|---|
| `LAY` | Layout and spacing |
| `TYP` | Typography |
| `COL` | Color and contrast |
| `DRK` | Dark mode |
| `BTN` | Buttons and calls to action |
| `FRM` | Forms and inputs |
| `NAV` | Navigation |
| `MOB` | Mobile and touch |
| `FBK` | Feedback, loading and empty states |
| `CMP` | Components and design system |
| `ICO` | Icons and imagery |
| `COP` | Copy and microcopy |
| `PRN` | UX principles |
| `SCR` | Screen patterns |
| `STY` | Style options |
| `MOT` | Motion and animation |
| `ENG` | Front-end engineering |
| `BRD` | Brand identity |

## Reference screens

`examples/` holds 49 original reference pages with 170 screens, including 21 dashboards. Each page is plain HTML and CSS with no external requests, cites the rule IDs it demonstrates and passes a WCAG AA contrast check. The router points an agent at the page that matches its task. The agent studies the semantics, states and details, then rebuilds the pattern with the project's own components and tokens. [`examples/README.md`](examples/README.md) lists every page and version.

### Dashboards v1–v21

|   |   |   |   |
|---|---|---|---|
| <a href="../../docs/screens/dashboard-v1.jpg"><img src="../../docs/screens/thumbs/dashboard-v1.jpg" alt="v1 example screen"></a><br><b>v1</b> · Analytics · <a href="examples/dashboard-v1.html">HTML</a> | <a href="../../docs/screens/dashboard-v2.jpg"><img src="../../docs/screens/thumbs/dashboard-v2.jpg" alt="v2 example screen"></a><br><b>v2</b> · Operations (dark) · <a href="examples/dashboard-v2.html">HTML</a> | <a href="../../docs/screens/dashboard-v3.jpg"><img src="../../docs/screens/thumbs/dashboard-v3.jpg" alt="v3 example screen"></a><br><b>v3</b> · Store bento · <a href="examples/dashboard-v3.html">HTML</a> | <a href="../../docs/screens/dashboard-v4.jpg"><img src="../../docs/screens/thumbs/dashboard-v4.jpg" alt="v4 example screen"></a><br><b>v4</b> · Personal finance · <a href="examples/dashboard-v4.html">HTML</a> |
| <a href="../../docs/screens/dashboard-v5.jpg"><img src="../../docs/screens/thumbs/dashboard-v5.jpg" alt="v5 example screen"></a><br><b>v5</b> · Sales CRM · <a href="examples/dashboard-v5.html">HTML</a> | <a href="../../docs/screens/dashboard-v6.jpg"><img src="../../docs/screens/thumbs/dashboard-v6.jpg" alt="v6 example screen"></a><br><b>v6</b> · Learning · <a href="examples/dashboard-v6.html">HTML</a> | <a href="../../docs/screens/dashboard-v7.jpg"><img src="../../docs/screens/thumbs/dashboard-v7.jpg" alt="v7 example screen"></a><br><b>v7</b> · Property · <a href="examples/dashboard-v7.html">HTML</a> | <a href="../../docs/screens/dashboard-v8.jpg"><img src="../../docs/screens/thumbs/dashboard-v8.jpg" alt="v8 example screen"></a><br><b>v8</b> · Workspace admin · <a href="examples/dashboard-v8.html">HTML</a> |
| <a href="../../docs/screens/dashboard-v9.jpg"><img src="../../docs/screens/thumbs/dashboard-v9.jpg" alt="v9 example screen"></a><br><b>v9</b> · Credit score (dark) · <a href="examples/dashboard-v9.html">HTML</a> | <a href="../../docs/screens/dashboard-v10.jpg"><img src="../../docs/screens/thumbs/dashboard-v10.jpg" alt="v10 example screen"></a><br><b>v10</b> · Creator (dark) · <a href="examples/dashboard-v10.html">HTML</a> | <a href="../../docs/screens/dashboard-v11.jpg"><img src="../../docs/screens/thumbs/dashboard-v11.jpg" alt="v11 example screen"></a><br><b>v11</b> · Fitness · <a href="examples/dashboard-v11.html">HTML</a> | <a href="../../docs/screens/dashboard-v12.jpg"><img src="../../docs/screens/thumbs/dashboard-v12.jpg" alt="v12 example screen"></a><br><b>v12</b> · Smart home (dark) · <a href="examples/dashboard-v12.html">HTML</a> |
| <a href="../../docs/screens/dashboard-v13.jpg"><img src="../../docs/screens/thumbs/dashboard-v13.jpg" alt="v13 example screen"></a><br><b>v13</b> · Logistics · <a href="examples/dashboard-v13.html">HTML</a> | <a href="../../docs/screens/dashboard-v14.jpg"><img src="../../docs/screens/thumbs/dashboard-v14.jpg" alt="v14 example screen"></a><br><b>v14</b> · Grid forecast · <a href="examples/dashboard-v14.html">HTML</a> | <a href="../../docs/screens/dashboard-v15.jpg"><img src="../../docs/screens/thumbs/dashboard-v15.jpg" alt="v15 example screen"></a><br><b>v15</b> · Accounts payable · <a href="examples/dashboard-v15.html">HTML</a> | <a href="../../docs/screens/dashboard-v16.jpg"><img src="../../docs/screens/thumbs/dashboard-v16.jpg" alt="v16 example screen"></a><br><b>v16</b> · Clinic monitoring · <a href="examples/dashboard-v16.html">HTML</a> |
| <a href="../../docs/screens/dashboard-v17.jpg"><img src="../../docs/screens/thumbs/dashboard-v17.jpg" alt="v17 example screen"></a><br><b>v17</b> · People operations · <a href="examples/dashboard-v17.html">HTML</a> | <a href="../../docs/screens/dashboard-v18.jpg"><img src="../../docs/screens/thumbs/dashboard-v18.jpg" alt="v18 example screen"></a><br><b>v18</b> · Security operations · <a href="examples/dashboard-v18.html">HTML</a> | <a href="../../docs/screens/dashboard-v19.jpg"><img src="../../docs/screens/thumbs/dashboard-v19.jpg" alt="v19 example screen"></a><br><b>v19</b> · Wind farm · <a href="examples/dashboard-v19.html">HTML</a> | <a href="../../docs/screens/dashboard-v20.jpg"><img src="../../docs/screens/thumbs/dashboard-v20.jpg" alt="v20 example screen"></a><br><b>v20</b> · Business cash · <a href="examples/dashboard-v20.html">HTML</a> |
| <a href="../../docs/screens/dashboard-v21.jpg"><img src="../../docs/screens/thumbs/dashboard-v21.jpg" alt="v21 example screen"></a><br><b>v21</b> · Home wall panel · <a href="examples/dashboard-v21.html">HTML</a> |   |   |   |

### Components and flows

|   |   |   |   |
|---|---|---|---|
| <a href="../../docs/screens/sign-in.jpg"><img src="../../docs/screens/thumbs/sign-in.jpg" alt="Sign-in example screen"></a><br><b>Sign-in</b> · split screen · <a href="examples/sign-in.html">HTML</a> | <a href="../../docs/screens/auth.jpg"><img src="../../docs/screens/thumbs/auth.jpg" alt="Account access example screen"></a><br><b>Account access</b> · v1–v5 · <a href="examples/auth.html">HTML</a> | <a href="../../docs/screens/auth-2.jpg"><img src="../../docs/screens/thumbs/auth-2.jpg" alt="Account access example screen"></a><br><b>Account access</b> · v6–v11 · <a href="examples/auth-2.html">HTML</a> | <a href="../../docs/screens/otp.jpg"><img src="../../docs/screens/thumbs/otp.jpg" alt="Codes and PINs example screen"></a><br><b>Codes and PINs</b> · 6 versions · <a href="examples/otp.html">HTML</a> |
| <a href="../../docs/screens/settings.jpg"><img src="../../docs/screens/thumbs/settings.jpg" alt="Settings example screen"></a><br><b>Settings</b> · security page · <a href="examples/settings.html">HTML</a> | <a href="../../docs/screens/navigation.jpg"><img src="../../docs/screens/thumbs/navigation.jpg" alt="Navigation example screen"></a><br><b>Navigation</b> · 5 versions · <a href="examples/navigation.html">HTML</a> | <a href="../../docs/screens/tab-bars.jpg"><img src="../../docs/screens/thumbs/tab-bars.jpg" alt="Tab bars example screen"></a><br><b>Tab bars</b> · 5 + spec · <a href="examples/tab-bars.html">HTML</a> | <a href="../../docs/screens/search.jpg"><img src="../../docs/screens/thumbs/search.jpg" alt="Search example screen"></a><br><b>Search</b> · 6 versions · <a href="examples/search.html">HTML</a> |
| <a href="../../docs/screens/charts.jpg"><img src="../../docs/screens/thumbs/charts.jpg" alt="Charts example screen"></a><br><b>Charts</b> · v1–v6 · <a href="examples/charts.html">HTML</a> | <a href="../../docs/screens/charts-2.jpg"><img src="../../docs/screens/thumbs/charts-2.jpg" alt="Charts example screen"></a><br><b>Charts</b> · v7–v12 · <a href="examples/charts-2.html">HTML</a> | <a href="../../docs/screens/cards.jpg"><img src="../../docs/screens/thumbs/cards.jpg" alt="Cards example screen"></a><br><b>Cards</b> · v1–v6 · <a href="examples/cards.html">HTML</a> | <a href="../../docs/screens/cards-2.jpg"><img src="../../docs/screens/thumbs/cards-2.jpg" alt="Cards example screen"></a><br><b>Cards</b> · v7–v12 · <a href="examples/cards-2.html">HTML</a> |
| <a href="../../docs/screens/tables.jpg"><img src="../../docs/screens/thumbs/tables.jpg" alt="Data tables example screen"></a><br><b>Data tables</b> · 6 versions · <a href="examples/tables.html">HTML</a> | <a href="../../docs/screens/calendar.jpg"><img src="../../docs/screens/thumbs/calendar.jpg" alt="Calendars example screen"></a><br><b>Calendars</b> · 5 versions · <a href="examples/calendar.html">HTML</a> | <a href="../../docs/screens/buttons.jpg"><img src="../../docs/screens/thumbs/buttons.jpg" alt="Buttons example screen"></a><br><b>Buttons</b> · v1–v6 · <a href="examples/buttons.html">HTML</a> | <a href="../../docs/screens/buttons-2.jpg"><img src="../../docs/screens/thumbs/buttons-2.jpg" alt="Buttons example screen"></a><br><b>Buttons</b> · v7–v12 · <a href="examples/buttons-2.html">HTML</a> |
| <a href="../../docs/screens/form-controls.jpg"><img src="../../docs/screens/thumbs/form-controls.jpg" alt="Form controls example screen"></a><br><b>Form controls</b> · v1–v6 · <a href="examples/form-controls.html">HTML</a> | <a href="../../docs/screens/form-controls-2.jpg"><img src="../../docs/screens/thumbs/form-controls-2.jpg" alt="Form controls example screen"></a><br><b>Form controls</b> · v7–v12 · <a href="examples/form-controls-2.html">HTML</a> | <a href="../../docs/screens/overlays.jpg"><img src="../../docs/screens/thumbs/overlays.jpg" alt="Menus and overlays example screen"></a><br><b>Menus and overlays</b> · 6 versions · <a href="examples/overlays.html">HTML</a> | <a href="../../docs/screens/feedback.jpg"><img src="../../docs/screens/thumbs/feedback.jpg" alt="Feedback example screen"></a><br><b>Feedback</b> · 6 versions · <a href="examples/feedback.html">HTML</a> |
| <a href="../../docs/screens/commerce.jpg"><img src="../../docs/screens/thumbs/commerce.jpg" alt="Commerce example screen"></a><br><b>Commerce</b> · 5 versions · <a href="examples/commerce.html">HTML</a> | <a href="../../docs/screens/pricing.jpg"><img src="../../docs/screens/thumbs/pricing.jpg" alt="Pricing example screen"></a><br><b>Pricing</b> · 4 versions · <a href="examples/pricing.html">HTML</a> | <a href="../../docs/screens/landing.jpg"><img src="../../docs/screens/thumbs/landing.jpg" alt="Landing pages example screen"></a><br><b>Landing pages</b> · 6 versions · <a href="examples/landing.html">HTML</a> | <a href="../../docs/screens/onboarding.jpg"><img src="../../docs/screens/thumbs/onboarding.jpg" alt="Onboarding and errors example screen"></a><br><b>Onboarding and errors</b> · v1–v6 · <a href="examples/onboarding.html">HTML</a> |
| <a href="../../docs/screens/onboarding-2.jpg"><img src="../../docs/screens/thumbs/onboarding-2.jpg" alt="Onboarding example screen"></a><br><b>Onboarding</b> · v7–v12 · <a href="examples/onboarding-2.html">HTML</a> | <a href="../../docs/screens/mobile-apps.jpg"><img src="../../docs/screens/thumbs/mobile-apps.jpg" alt="Mobile apps example screen"></a><br><b>Mobile apps</b> · 5 versions · <a href="examples/mobile-apps.html">HTML</a> | <a href="../../docs/screens/messaging.jpg"><img src="../../docs/screens/thumbs/messaging.jpg" alt="Messaging and assistant example screen"></a><br><b>Messaging and assistant</b> · 4 versions · <a href="examples/messaging.html">HTML</a> | <a href="../../docs/screens/brand.jpg"><img src="../../docs/screens/thumbs/brand.jpg" alt="Brand guidelines example screen"></a><br><b>Brand guidelines</b> · 6 versions · <a href="examples/brand.html">HTML</a> |

## Security baseline

LaunchGuard ships a 20-control baseline in `modules/launchguard/references/security-baseline.md`. Each control lists what to do, the common trap and how to verify it. A security-sensitive change gets a scoped check of the controls it touches; a launch review reports all 20.

| Area | Controls |
|---|---|
| Secrets and keys | 1. Hide API keys · 2. Purge Git secrets (rotate first) · 3. Use only the public database key in the client |
| Data access | 4. Enable row-level security · 5. Encrypt sensitive data · 6. Enforce server-side auth · 7. Lock record access · 8. Block field tampering |
| Sessions and login | 9. Secure session cookies · 10. Hash passwords · 11. Rate-limit login · 12. Add bot protection |
| Input and output | 13. Parameterize queries · 14. Validate all input · 15. Escape user content · 16. Restrict file uploads · 17. Trim API responses |
| Platform | 18. Add security headers · 19. Force HTTPS · 20. Scan dependencies |

## Bundled tools

| Tool | What it does |
|---|---|
| `scripts/check_package.py` | Checks package integrity: one `SKILL.md`, a valid pattern library and UI rulebook, all modules present, and reference screens that are listed, self-contained and cite only real rule IDs |
| `modules/launchguard/scripts/preflight_scan.py` | Read-only, redacted heuristic scan for secret-shaped literals, public secret env names, disabled TLS verification, wildcard CORS, debug flags, HTML sinks, sensitive logging, cookies with HttpOnly or Secure disabled, and fast hashes used on passwords |
| `modules/credential-shield/scripts/simulate_policy.py` | Offline, synthetic demonstration of how distributed credential-stuffing campaigns become visible through combined signals |
| `modules/engineering-workflow/scripts/diff_scope.py` | Self-check of a diff: out-of-scope files, whitespace churn, debug leftovers, focused or skipped tests, removed assertions, lockfile churn. Never prints changed lines |
| `modules/engineering-practices/scripts/migration_check.py` | Flags SQL migrations likely to lock tables or lose data (drops, in-place renames, blocking index builds, full-table updates, missing lock timeouts) |
| `modules/engineering-practices/scripts/oss_readiness.py` | Read-only open-source readiness check: front-door files, LICENSE text versus manifest licenses, secret-like tracked files and sensitive names in history, internal hosts, private registries, dependencies outside the repository, commit email domains; never prints file contents |
| `modules/code-security-review/scripts/code_audit.py` | Ranks files to read first, scans local git history for secrets without printing values, checks CI workflow files, validates the findings JSON |
| `modules/code-security-review/scripts/supply_chain.py` | Maps which GitHub Actions workflows outsiders can trigger and where their text flows (AI agent prompts and environments, environment files, reusable-workflow and composite-action inputs, agent output in scripts); reads ten lockfile formats for install-time code, sources outside the registry, mixed registries and credentials in URLs |
| `modules/code-security-review/scripts/sarif_triage.py` | Summarizes Semgrep, CodeQL and other SARIF with correctly resolved levels, lists results that are new against a baseline, and writes untriaged results as leads the findings validator accepts |
| `modules/code-security-review/scripts/firebase_rules.py` | Reads Firestore, Storage and Realtime Database rules offline and flags open, test-mode, signed-in-only and unvalidated-write rules; never prints rule conditions |
| `modules/code-security-review/scripts/rls_check.py` | Replays PostgreSQL migrations offline and lists row-level security leads: tables without RLS, always-true and signed-in-only policies, policies that trust `user_metadata`, views without `security_invoker`, materialized views, exposed or unpinned `SECURITY DEFINER` functions, and secrets in client-bundled environment variables (names only) |
| `modules/code-security-review/scripts/har_summary.py` | Summarizes a captured HTTP session (HAR): request counts, hosts, methods, status classes and content types, plus a report of where credentials and tokens appear; never prints header, cookie, body or query values |
| `modules/legal-ready/scripts/legal_scan.py` | Scans a project for legal-readiness signals: policy pages, consent mechanism, third-party trackers, images without alt text, pre-ticked consent, unsubscribe links, a data deletion route |
| `modules/agent-safety/scripts/guard_command.py` | Classifies a shell command as allow, ask or deny with a reason and a safer alternative; usable as an opt-in pre-tool hook; also checks commands inside awk `system()` calls and GNU `parallel` templates |
| `modules/agent-safety/scripts/scan_skill.py` | Read-only static scan of a third-party skill, plugin, MCP server or hook folder before installation |
| `modules/codebase-map/scripts/map_codebase.py` | Maps a repository: entry points, routes, Python and JS/TS import graph, top-level symbols and hotspots; never opens credential files; `--exclude` leaves out tracked folders the task does not need |
| `modules/documents/scripts/ooxml_inspect.py` | Inspects Word, Excel and PowerPoint files for tracked changes, comments, hidden content, leftover placeholders, uncalculated formulas and off-slide shapes |
| `modules/builder-tools/scripts/lint_skill.py` | Lints an Agent Skill folder: frontmatter limits, broken file references, oversized files without contents lists, stray caches |
| `modules/stacks/scripts/detect_stack.py` | Detects stacks, version pins, package managers, lockfiles and the project's own build, test, lint and format commands from manifests, task runners and CI files; never opens credential files |
| `modules/cloud-infrastructure/scripts/plan_review.py` | Reviews Terraform or OpenTofu plan JSON: deletes and replacements of data stores, protection switched off, IAM changes and wildcard grants, inbound access from anywhere, public data, imports and moves; never prints attribute values |
| `modules/data-engineering/scripts/csv_profile.py` | Offline profile of a CSV or TSV file: encoding and delimiter, types, nulls, distinct counts, numeric summaries, keys and suspicious values; prints no cell values unless asked |
| `modules/ml-engineering/scripts/split_check.py`, `compare_scores.py`, `rank_metrics.py` | Leakage across dataset splits; paired model comparison (corrected resampled t-test, bootstrap, McNemar, Holm and Benjamini-Hochberg); ranking metrics |
| `modules/scientific-computing/scripts/resource_check.py`, `convergence_order.py` | Usable cores, memory, disk and GPU signs without running other programs; observed order of convergence, Richardson extrapolation and grid convergence index |
| `modules/life-sciences/scripts/interval_check.py`, `counts_check.py`, `bio_id_check.py`, `dicom_phi_check.py` | Interval files and coordinate conversion; count matrices and sample sheets before differential expression; identifier shapes across 47 types; identifying data left in DICOM headers, values hidden |
| `modules/research-writing/scripts/bib_check.py` | Offline BibTeX check: duplicate keys and DOIs, missing fields per entry type, malformed DOIs and years, unbalanced braces, cited versus defined keys |
| `modules/creative-media/scripts/organize_plan.py` | Plans file moves by type and date, or checks a rename list, with collisions resolved; never touches files; can emit apply and undo scripts that never overwrite |
| `modules/integrations/scripts/integration_scan.py` | Finds risky integration code: unverified or re-serialized webhooks, plain digest comparisons, payments without idempotency keys, credentials in URLs, broad scopes, server secrets in client modules |
| `modules/blockchain-dev/scripts/move_check.py` | Finds risky Move packages and dApp repositories: tracked key files, public functions returning refs or signers, exposed randomness, moving-branch dependencies |
| `modules/search-visibility/scripts/seo_check.py` | Offline check of built HTML, `robots.txt` and XML sitemaps: titles and descriptions, `h1`, canonicals, `meta robots`, `hreflang` codes and return links, image `alt`, JSON-LD that parses with `@type` (retired features flagged), Open Graph and X cards, `robots.txt` syntax and RFC 9309 rule evaluation, sitemap syntax, limits and listed-URL status |
| `modules/agent-engineering/scripts/run_plan_check.py`, `usage_cost.py` | Checks agent loop plans for budgets, stop conditions, checkpoints, approval gates, payment caps and secrets; reports tokens, cost and cache use from usage logs and a dated price file |
| `modules/networking/scripts/ios_config_lint.py` | Offline lint of saved IOS or IOS-XE configurations: Telnet, SSH version, clear-text and type 7 secrets, AAA, logging, NTP, SNMP communities, unused ports; never prints secret values |
| `modules/business-ops/scripts/reorder_point.py` | Demand statistics, demand patterns, ABC and XYZ classes, safety stock and reorder points from a demand CSV |
| `modules/code-security-review/scripts/audit_record.py` | Validates an audit coverage record against the findings and states the strongest claim it supports; checks stricter finding fields |
| `modules/builder-tools/scripts/grade_trace.py`, `modules/agent-safety/scripts/audit_mcp_config.py` | Grades agent tool-call traces against a step spec; static review of MCP server declarations |
| `modules/engineering-workflow/scripts/affected_checks.py`, `modules/engineering-practices/scripts/i18n_sync.py` | Lists the checks a change needs from a module ledger; checks translation catalogs against the source catalog |
| `modules/search-visibility/scripts/seo_drift.py` | Snapshots the search-relevant state of a build and reports regressions between snapshots |
| `modules/ml-engineering/scripts/bench_compare.py`, `modules/blockchain-dev/scripts/evm_check.py`, `modules/life-sciences/scripts/hl7v2_check.py` | Compares two timing samples; Keccak-256 beside SHA3-256, selectors, event topics, EIP-55 checksums and exact unit conversion; HL7 v2 message checks that never print field values |
| `assets/review-template.md` | Template for the agent's change report |

Every script uses the Python 3 standard library only, is read-only toward the project it inspects and never touches the network.

Run the scanner against an app:

```bash
python3 <skill-root>/modules/launchguard/scripts/preflight_scan.py \
  --root . --json-out security/launchguard-scan.json
```

## Validate the package

From inside this folder:

```bash
python3 scripts/check_package.py --root .
python3 -m unittest discover -s tests -v
for t in modules/*/tests; do python3 -m unittest discover -s "$t" -v; done
```

The suites hold 1266 tests in total. They validate the package and its helper scripts, not the security or design of any particular application.

## Package layout

```text
productcraft/
├── SKILL.md                     # single entry point and router
├── README.md                    # this file
├── LICENSE                      # MIT
├── WORKSPACE-SETUP-PROMPT.txt   # paste-in installer prompt for ZIP uploads
├── assets/review-template.md
├── modules/
│   ├── product-design.md
│   ├── interaction-feedback.md
│   ├── forms-conversion.md
│   ├── data-and-product-surfaces.md
│   ├── responsive-accessibility.md
│   ├── ethical-persuasion.md
│   ├── ui-rules.md              # routes to the UI rulebook
│   ├── language-choice.md       # when and how to offer Rust
│   ├── lean-output.md           # opt-in shorter answers
│   ├── engineering-workflow/    # tracks, planning, test-first, debugging, reviewing changes; diff self-check
│   ├── engineering-practices/   # APIs, migrations, resilience, performance, CI/CD, advanced testing, open-sourcing; migration and readiness checks
│   ├── ui-distiller/            # guide + design rules, patterns, quality gate, taste, style catalog
│   ├── code-security-review/    # audit phases, vulnerability classes, domain guides; audit, supply-chain, SARIF and Firebase helpers
│   ├── credential-shield/       # guide, references, policy example, simulator, tests
│   ├── launchguard/             # guide, security baseline, references, scanner, tests, report templates
│   ├── legal-ready/             # 20 legal-readiness items, owner questionnaire, scanner
│   ├── agent-safety/            # stop-check, secrets, guided setup, isolation, extension vetting, command guard, scanner
│   ├── codebase-map/            # repository mapper and how to use it
│   ├── documents/               # Word, Excel, PowerPoint, PDF and animated media guides, OOXML inspector
│   ├── builder-tools/           # Agent Skills, MCP servers, Playwright, agent config; skill linter
│   ├── stacks/                  # language and framework guides; stack detector
│   ├── cloud-infrastructure/    # IaC and cloud, plan and diff only; plan reviewer
│   ├── data-engineering/        # SQL, dataframes, EDA, charts, public data; CSV profiler
│   ├── ml-engineering/          # evaluation, ML, statistics, LLM apps; split and score checks
│   ├── scientific-computing/    # numerical methods, HPC, scientific libraries; resource and convergence checks
│   ├── life-sciences/           # bio and chem analysis, databases, clinical, lab; interval, counts, ID, DICOM checks
│   ├── research-writing/        # literature, citations, papers, reviews, talks; BibTeX checker
│   ├── creative-media/          # art, posters, video, images, EPUB, file organization; move planner
│   ├── integrations/            # third-party APIs, OAuth, webhooks; integration scanner
│   ├── blockchain-dev/          # Move on Aptos and Solana; Move checker
│   ├── search-visibility/       # SEO and AI answers: crawl, index, structure, markup, measurement, content; checker and drift diff
│   ├── agent-engineering/       # harnesses, loops, evals, cost, orchestration, memory; run-plan check and cost report
│   ├── networking/              # Cisco IOS, automation, BGP, troubleshooting, homelab; IOS config linter
│   └── business-ops/            # supply chain, billing, investors, marketing, contracts; reorder-point calculator
├── examples/                    # reference screens: HTML pages, tokens.css, gallery.css, README index
├── references/
│   ├── ui-rules/                # UI rulebook, one file per category
│   ├── ui-rules-index.json
│   ├── pattern-library.md       # UI/UX patterns with rules and guardrails
│   └── pattern-index.json
├── scripts/check_package.py
└── tests/test_package.py
```

## Limitations

- Pattern rules are heuristics, not mandatory design laws. Security, accessibility, facts and user consent always take precedence.
- ProductCraft is a build guide. It does not guarantee security, accessibility compliance or a correct implementation in your app.
- For apps that handle substantial money or sensitive data, arrange a qualified human security review before launch.
- Legal Ready is general guidance, not legal advice. Have a qualified lawyer review policies and obligations for your business and markets.
- The agent-safety command guard is a seatbelt, not a sandbox. For real isolation, run agents in a devcontainer, container or VM without production credentials (`modules/agent-safety/references/isolation.md`).

## License

Released under the [MIT License](LICENSE). Anyone can use, copy, modify and share ProductCraft, including for commercial work, as long as the copyright and license notice stay with the copies.

© 2026 Sora Labs
