export const esm = 'esm';
